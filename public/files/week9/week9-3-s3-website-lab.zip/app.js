// QuickTable 레스토랑 예약 시스템 - Week 9-3
// Amazon API Gateway + Amazon Cognito 연동

// TODO: Week 4-2에서 생성한 API Gateway URL로 변경
const API_BASE_URL = 'https://YOUR-API-ID.execute-api.ap-northeast-2.amazonaws.com/prod';

// 예약 생성
async function createReservation(event) {
    event.preventDefault();
    const resultDiv = document.getElementById('reservation-result');

    const reservation = {
        restaurantName: document.getElementById('restaurant').value,
        date: document.getElementById('date').value,
        time: document.getElementById('time').value,
        partySize: parseInt(document.getElementById('party-size').value)
    };

    try {
        const response = await fetch(`${API_BASE_URL}/reservations`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(reservation)
        });

        if (response.ok) {
            const data = await response.json();
            resultDiv.innerHTML = `<p class="success">✅ 예약이 완료되었습니다! (ID: ${data.reservationId || 'N/A'})</p>`;
        } else {
            resultDiv.innerHTML = '<p class="error">❌ 예약에 실패했습니다. API URL을 확인하세요.</p>';
        }
    } catch (error) {
        resultDiv.innerHTML = '<p class="error">❌ API 연결에 실패했습니다. API Gateway URL을 확인하세요.</p>';
    }
    resultDiv.style.display = 'block';
}

// 예약 조회
async function loadReservations() {
    const listDiv = document.getElementById('reservations-list');
    const noDiv = document.getElementById('no-reservations');
    const tbody = document.getElementById('reservations-body');

    try {
        const response = await fetch(`${API_BASE_URL}/reservations`);
        if (response.ok) {
            const reservations = await response.json();
            if (reservations.length > 0) {
                tbody.innerHTML = reservations.map(r => `
                    <tr>
                        <td>${r.reservationId}</td>
                        <td>${r.restaurantName}</td>
                        <td>${r.date}</td>
                        <td>${r.time}</td>
                        <td>${r.partySize}명</td>
                        <td>${r.status}</td>
                    </tr>
                `).join('');
                listDiv.style.display = 'block';
                noDiv.style.display = 'none';
            } else {
                listDiv.style.display = 'none';
                noDiv.style.display = 'block';
            }
        }
    } catch (error) {
        noDiv.innerHTML = '<p class="error">❌ API 연결에 실패했습니다.</p>';
        noDiv.style.display = 'block';
    }
}

// 폼 이벤트 바인딩
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('reservation-form');
    if (form) {
        form.addEventListener('submit', createReservation);
    }
});
