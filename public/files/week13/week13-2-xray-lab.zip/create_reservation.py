"""
QuickTable 예약 생성 Lambda 함수 (AWS X-Ray SDK 통합)
Week 13-2: AWS X-Ray를 활용한 서버리스 애플리케이션 추적

이 함수는 AWS X-Ray SDK를 사용하여 예약 생성 과정을 추적합니다.
API Gateway POST /reservations 요청을 처리합니다.
"""

import json
import logging
import os
import uuid
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS X-Ray SDK
from aws_xray_sdk.core import xray_recorder
from aws_xray_sdk.core import patch_all

# AWS SDK 자동 패치 (DynamoDB 호출 자동 추적)
patch_all()

import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
TABLE_NAME = os.environ.get('TABLE_NAME', 'Reservations')


def lambda_handler(event, context):
    """예약 생성 핸들러 - X-Ray 추적 활성화"""

    segment = xray_recorder.current_segment()
    segment.put_annotation('operation', 'create_reservation')
    segment.put_annotation('function_name', context.function_name)

    try:
        body = json.loads(event.get('body', '{}'))

        # 입력 검증
        subsegment = xray_recorder.begin_subsegment('validate_input')
        required_fields = ['userId', 'restaurantName', 'date', 'time', 'partySize']
        missing = [f for f in required_fields if f not in body]
        if missing:
            subsegment.put_annotation('validation', 'failed')
            xray_recorder.end_subsegment()
            return response(400, {'message': f'Missing fields: {missing}'})
        subsegment.put_annotation('validation', 'passed')
        xray_recorder.end_subsegment()

        # 예약 생성
        subsegment = xray_recorder.begin_subsegment('create_dynamodb_item')
        table = dynamodb.Table(TABLE_NAME)
        reservation_id = f"RSV-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8]}"

        item = {
            'userId': body['userId'],
            'reservationId': reservation_id,
            'restaurantName': body['restaurantName'],
            'date': body['date'],
            'time': body['time'],
            'partySize': int(body['partySize']),
            'status': 'confirmed',
            'createdAt': datetime.now().isoformat()
        }

        table.put_item(Item=item)
        subsegment.put_annotation('reservation_id', reservation_id)
        subsegment.put_metadata('item', item)
        xray_recorder.end_subsegment()

        logger.info(f"Reservation created: {reservation_id}")
        return response(201, {'message': 'Reservation created', 'reservationId': reservation_id})

    except ClientError as e:
        logger.error(f"DynamoDB error: {e.response['Error']['Code']}")
        segment.put_annotation('error', e.response['Error']['Code'])
        return response(500, {'message': 'Failed to create reservation'})
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        segment.put_annotation('error', str(e))
        return response(500, {'message': 'Internal server error'})


def response(status_code, body):
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body, default=str)
    }
