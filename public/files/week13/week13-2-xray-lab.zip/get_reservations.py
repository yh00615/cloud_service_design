"""
QuickTable 예약 조회 Lambda 함수 (AWS X-Ray SDK 통합)
Week 13-2: AWS X-Ray를 활용한 서버리스 애플리케이션 추적

이 함수는 AWS X-Ray SDK를 사용하여 예약 조회 과정을 추적합니다.
API Gateway GET /reservations 요청을 처리합니다.
"""

import json
import logging
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS X-Ray SDK
from aws_xray_sdk.core import xray_recorder
from aws_xray_sdk.core import patch_all

# AWS SDK 자동 패치 (DynamoDB 호출 자동 추적)
patch_all()

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
TABLE_NAME = os.environ.get('TABLE_NAME', 'Reservations')


def lambda_handler(event, context):
    """예약 조회 핸들러 - X-Ray 추적 활성화"""

    segment = xray_recorder.current_segment()
    segment.put_annotation('operation', 'get_reservations')
    segment.put_annotation('function_name', context.function_name)

    try:
        # 쿼리 파라미터에서 userId 추출
        params = event.get('queryStringParameters') or {}
        user_id = params.get('userId')

        table = dynamodb.Table(TABLE_NAME)

        if user_id:
            # 특정 사용자의 예약 조회
            subsegment = xray_recorder.begin_subsegment('query_by_user')
            subsegment.put_annotation('user_id', user_id)

            result = table.query(
                KeyConditionExpression=Key('userId').eq(user_id)
            )
            items = result.get('Items', [])
            subsegment.put_annotation('item_count', len(items))
            xray_recorder.end_subsegment()
        else:
            # 전체 예약 조회 (최대 50건)
            subsegment = xray_recorder.begin_subsegment('scan_all')

            result = table.scan(Limit=50)
            items = result.get('Items', [])
            subsegment.put_annotation('item_count', len(items))
            xray_recorder.end_subsegment()

        logger.info(f"Retrieved {len(items)} reservations")
        return response(200, {'reservations': items, 'count': len(items)})

    except ClientError as e:
        logger.error(f"DynamoDB error: {e.response['Error']['Code']}")
        segment.put_annotation('error', e.response['Error']['Code'])
        return response(500, {'message': 'Failed to get reservations'})
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        segment.put_annotation('error', str(e))
        return response(500, {'message': 'Internal server error'})


def response(status_code, body):
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body, default=str)
    }
